export interface ISearchFormData {
	searchTerm: string
}
