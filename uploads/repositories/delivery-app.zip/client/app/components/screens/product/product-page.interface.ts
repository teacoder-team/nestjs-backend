import { IProduct } from '@/types/product.interface'

export interface IProductComponent {
	product: IProduct
}
